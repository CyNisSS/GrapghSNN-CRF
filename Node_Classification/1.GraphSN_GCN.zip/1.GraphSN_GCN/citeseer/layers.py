import math
import torch
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import torch.nn as nn
import numpy as np
# from IPython.core.debugger import Tracer
from scipy.linalg import fractional_matrix_power
import torch.nn.functional as F


class Graphsn_GCN(Module):

    def __init__(self, in_features, out_features, dropout_p,bias=True):
        super(Graphsn_GCN, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.drop = nn.Dropout(p=dropout_p)
        self.act = nn.ELU()

        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        """可学习参数𝛄"""
        self.eps = nn.Parameter(torch.FloatTensor(1))

        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 0.95 / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)

        stdv_eps = 0.21 / math.sqrt(self.eps.size(0))
        nn.init.constant_(self.eps, stdv_eps)

        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        # 把主对角线元素 x eps
        v = (self.eps) * torch.diag(adj)
        mask = torch.diag(torch.ones_like(v))
        adj = mask * torch.diag(v) + (1. - mask) * adj
        #input = self.drop(input)
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)

        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
            + str(self.in_features) + ' -> ' \
            + str(self.out_features) + ')'


class CRF(Module):
    def __init__(self, infeature, outfeature, mode='None'):
        super(CRF, self).__init__()

        self.infeature = infeature
        # self.g_matrix = None
        # self.s_matrix = None
        self.outfeature = outfeature
        self.mode = mode
        self.alpha = nn.Parameter(torch.rand(1))
        self.beta = nn.Parameter(torch.rand(1))
        self.W_a = nn.Parameter(torch.rand(infeature, outfeature))
        self.W_b = nn.Parameter(torch.rand(infeature, outfeature))
        
        #self.fc1 = nn.Linear(infeature, outfeature)
        #self.fc2 = nn.Linear(infeature, outfeature)
        self.sftmx = nn.Softmax(1)
        self.leaky = nn.LeakyReLU()


        self.theta = nn.Parameter(torch.FloatTensor(1))
        self.reset_parameters()

    def reset_parameters(self):
        # stdv1 = 0.95 / math.sqrt(self.W_a.size(1))
        # self.W_a.data.uniform_(-stdv1, stdv1)
        self.W_a = nn.init.xavier_normal_(self.W_a, gain=1)

        # stdv2 = 0.95 / math.sqrt(self.W_b.size(1))
        # self.W_b.data.uniform_(-stdv2, stdv2)
        self.W_b = nn.init.xavier_normal_(self.W_b, gain=1)

        stdv_a = 0.21 / math.sqrt(self.alpha.size(0))
        nn.init.constant_(self.alpha, stdv_a)

        stdv_b = 0.21 / math.sqrt(self.beta.size(0))
        nn.init.constant_(self.beta, stdv_b)

    # def compute_gij(self,x):

    def forward(self, x):
        #compute sij & gij
        a = torch.mm(x, self.W_a)
        b = torch.mm(x, self.W_b).t()

        s_matrix = torch.mm(a, b)
        # y = x.detach().numpy()
        if self.mode == 'G':

            a = F.normalize(a, p=2, dim=1)
            g_matrix = torch.mm(a, a.t())
            g_matrix = g_matrix - torch.diag(g_matrix)
            theta = torch.exp(self.theta)
            theta = 2 * theta * theta
            g_matrix = torch.exp(g_matrix / (2 * theta * theta))

        else:
            g_matrix = self.sftmx(s_matrix)
        g_matrix = self.leaky(g_matrix)
        x = self.alpha * x
        #后一项是需要迭代的Hk，为了得到Hk+1，此处用x暂时代替Hk
        x = x + self.beta * g_matrix.sum(1, keepdim=True) * x
        x = x / (self.alpha + self.beta)

        return x.float() if self.mode == 'G' else x



"""把N x C 的X pooling成 (n = N x top_k_ratio) x C 的X， 并得到 新adj nxn  """

class Pool(Module):

    def __init__(self, k ,in_dim, p):
        super(Pool, self).__init__()
        self.k = k
        self.sigmoid = nn.Sigmoid()
        self.proj = nn.Linear(in_dim, 1)
        self.drop = nn.Dropout(p=p) if p > 0 else nn.Identity()
        self.reset_parameter()

    def reset_parameter(self):
        nn.init.xavier_uniform_(self.proj.weight)
    def forward(self,adj, x):
        z = self.drop(x)
        weights = self.proj(z).squeeze()
        scores = self.sigmoid(weights)
        return top_k(scores, adj, x, self.k)

class Upool(Module):

    def __init__(self,*args):
        super(Upool,self).__init__()

    def forward(self, adj, x, idx):
        new_x = x.new_zeros(adj.shape[0], x.shape[1])
        new_x[idx] = x
        return adj, new_x

def top_k(scores, adj, x, k):
    num_nodes = adj.shape[0]
    v, idx = torch.topk(scores, int(k * num_nodes))
    new_x = x[idx, :]
    v = torch.unsqueeze(v, -1)
    new_x = torch.mul(new_x,v)
    #un_adj = adj.bool().float()
    #un_adj = torch.matmul(un_adj, un_adj).bool().float()
    un_adj = adj[idx, :]
    un_adj = adj[:, idx]
    return un_adj, new_x, idx


class CRF_NN(Module):
    def __init__(self, in_dim, out_dim, num_iters, **kwargs):
        super(CRF_NN, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.num_iters = num_iters
#        self.adj = adj
        self.alpha = nn.Parameter(torch.zeros(1))
        self.beta = nn.Parameter(torch.zeros(1))
        self.w_a = nn.Parameter(torch.nn.init.xavier_uniform_(torch.empty(in_dim, out_dim)))
        self.w_b = nn.Parameter(torch.nn.init.xavier_uniform_(torch.empty(in_dim, out_dim)))

    def forward(self, x):
        output = x
        x1 = torch.matmul(x, self.w_a)
        x2 = torch.matmul(x, self.w_b)

        logits = torch.matmul(x1, x2.t())
        similarity = F.softmax(F.leaky_relu(logits), dim=1)
        gi = torch.sum(similarity, dim=1, keepdim=True)
        gi = F.normalize(gi)
        print(gi.shape)

        alpha = torch.exp(self.alpha)
        beta = torch.exp(self.beta)
        for i in range(self.num_iters):
            output = (alpha * x + beta * gi * output)
            output = output / (alpha + beta * gi)
        return output
