import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch
from layers import Graphsn_GCN, CRF, Pool, Upool,CRF_NN


class GNN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, ks):
        super(GNN, self).__init__()

        self.gc1 = Graphsn_GCN(nfeat, nhid,dropout)
        self.gc2 = Graphsn_GCN(nhid, nclass,dropout)
        self.dropout = dropout

        self.ks = ks
        self.bottom_gcn = Graphsn_GCN(nhid, nhid,dropout)
        self.pools = nn.ModuleList()
        self.unpools = nn.ModuleList()
        self.crfs = nn.ModuleList()
        self.upgcn = nn.ModuleList()
        self.downgcn = nn.ModuleList()
        self.layer_n = len(ks)
        for i in range(self.layer_n):
            self.downgcn.append(Graphsn_GCN(nhid, nhid,dropout))
            self.upgcn.append(Graphsn_GCN(nhid, nhid,dropout))
            self.pools.append(Pool(ks[i], nhid, dropout))
            self.crfs.append(CRF_NN(nhid, nhid, 2))
            self.unpools.append(Upool(nhid, nhid, dropout))
        Initializer.weight_init(self)
    def forward(self, x, adj):
        adj_ms =[]
        indices_list = []
        down_outputs = []
        xs = []
        x = self.gc1(x, adj)
        orig_x = x
        #print('origin x : ', orig_x.shape)
        #x = self.crfs[0](x) 不可行
        for i in range(self.layer_n):
            #x = self.crfs[i](x)
            x = self.downgcn[i](x, adj)
            adj_ms.append(adj)
            down_outputs.append(x)
            adj, x, idx = self.pools[i](adj, x)
            indices_list.append(idx)
        x = self.bottom_gcn(x, adj)

        #print('after pool x :x.shape:', x.shape)
        for i in range(self.layer_n):
            up_idx = self.layer_n - i -1
            adj, idx = adj_ms[up_idx], indices_list[up_idx]
            adj, x = self.unpools[up_idx](adj, x,  idx)
            x = self.upgcn[i](x, adj)
            #x = self.crfs[i](x)
            xs.append(x)
        #print('after Unpool x.shape:', x.shape)
        x = x.add(orig_x)
        #xs.append(x)"""

        x = self.gc2(x, adj)
        return F.log_softmax(x, dim=-1)


class Initializer(object):
    @classmethod
    def _golorot_uniform(cls, w):
        if len(w.size()) == 2:
            fan_in, fan_out = w.size
        elif len(w.size()) == 3:
            fan_in = w.size()[1] * w.size()[2]
            fan_out = w.size()[0] * w.size()[2]
        else:
            fan_in = np.prod(w.size())
            fan_out = np.prob(w.size())
        #print('in%d, out%d\t',fan_in,fan_out)
        limit  = np.sqrt(6.0 / (fan_in + fan_out))
        w.uniform_(-limit, limit)
    @classmethod
    def _param_init(cls, m):
        if isinstance(m, nn.parameter.Parameter):
            cls._golorot_uniform(m.data)
        elif isinstance(m, nn.ParameterList):
            m.bias.data.zero_()
            cls._golorot_uniform(m.weight.data)
    @classmethod
    def weight_init(cls, m):
        for p in m.modules():
            if isinstance(p, nn.ParameterList):
                for pp in p:
                    cls._param_init(pp)
            else:
                cls._param_init(p)
        for name, p in m.named_parameters():
            if '.' not in name:
                cls._param_init(p)
