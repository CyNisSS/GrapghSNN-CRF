from __future__ import division
from __future__ import print_function

import time
import argparse
import numpy as np
import os

import torch
import torch.nn.functional as F
import torch.optim as optim
import networkx as nx
from scipy import sparse
from scipy.linalg import fractional_matrix_power

from utils import *
from models import GNN
from dataset_utils import DataLoader

import warnings
warnings.filterwarnings('ignore')

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=128,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.9,
                    help='Dropout rate (1 - keep probability).')
parser.add_argument('--dataset', default='citeseer', help='Dataset name.')
parser.add_argument('-ks', nargs='+', type=float ,default=[0.9,0.7])


args = parser.parse_args("")

print(f'args config: {args} ')
np.random.seed(args.seed)
torch.manual_seed(args.seed)

dname = args.dataset
dataset = DataLoader(dname)
data = dataset[0]

A_norm, A, X, labels, idx_train, idx_val, idx_test = load_citation_data(data)
start_time = time.time()
#G = nx.from_numpy_matrix(A)
G = nx.from_numpy_array(A)


#edges = list(G.edges())
#print(edges)

#print("G:",G,'G.adj:',G.adj, "G.edge:",G.edges)

feature_dictionary = {}

for i in np.arange(len(labels)):
    feature_dictionary[i] = labels[i]

nx.set_node_attributes(G, feature_dictionary, "attr_name")

sub_graphs = []

for i in np.arange(len(A)):
    s_indexes = []
    for j in np.arange(len(A)):
        s_indexes.append(i)
        if(A[i][j]==1):
            s_indexes.append(j)
    sub_graphs.append(G.subgraph(s_indexes))

subgraph_nodes_list = []

for i in np.arange(len(sub_graphs)):
    subgraph_nodes_list.append(list(sub_graphs[i].nodes))

sub_graphs_adj = []
for index in np.arange(len(sub_graphs)):
    sub_graphs_adj.append(nx.adjacency_matrix(sub_graphs[index]).toarray())

new_adj = torch.zeros(A.shape[0], A.shape[0])
#使用新的adj，计算各个节点之间边的权重，权重值根据两个节点子图重合度来确定，建立了独特的关系，对应论文中的𝔀
for node in np.arange(len(subgraph_nodes_list)):
    sub_adj = sub_graphs_adj[node]
    for neighbors in np.arange(len(subgraph_nodes_list[node])):
        index = subgraph_nodes_list[node][neighbors]
        count = torch.tensor(0).float()
        if(index==node):
            continue
        else:
            c_neighbors = set(subgraph_nodes_list[node]).intersection(subgraph_nodes_list[index])
            if index in c_neighbors:
                nodes_list = subgraph_nodes_list[node]
                sub_graph_index = nodes_list.index(index)
                c_neighbors_list = list(c_neighbors)
                for i, item1 in enumerate(nodes_list):
                    if(item1 in c_neighbors):
                        for item2 in c_neighbors_list:
                            j = nodes_list.index(item2)
                            count += sub_adj[i][j]

            new_adj[node][index] = count/2
            new_adj[node][index] = new_adj[node][index]/(len(c_neighbors)*(len(c_neighbors)-1))
            new_adj[node][index] = new_adj[node][index] * (len(c_neighbors)**1)

print('new_adj:', new_adj)
features = torch.FloatTensor(X)
labels = torch.LongTensor(labels)
#公式里的A/A每行的和，对A做归一化
#这样可以将邻接矩阵转化为概率转移矩阵。
weight = torch.FloatTensor(new_adj)
weight = weight / weight.sum(1, keepdim=True)

#对应第一项系数，对V节点自身操作----改
#coeff = weight.sum(1, keepdim=True) + 1
#coeff = torch.diag((coeff.T)[0])
#print("coeff = \n", coeff)

#对应第二项系数"""
#print(" 原weight = \n" , weight)
weight = weight + torch.FloatTensor(A)#因为A中元素，均为1，对应第二项系数A` + 1
#print("weight = 是否 = 原weight + 1 \n" , weight)
#原代码位置"""
coeff = weight.sum(1, keepdim=True)
coeff = torch.diag((coeff.T)[0])

weight = weight + coeff

weight = weight.detach().numpy()
weight = np.nan_to_num(weight, nan=0)
#计算GCN中的D-1/2"""
row_sum = np.array(np.sum(weight, axis=1))
degree_matrix = np.matrix(np.diag(row_sum+1))

D = fractional_matrix_power(degree_matrix, -0.5)
A_tilde_hat = D.dot(weight).dot(D)

adj = torch.FloatTensor(A_tilde_hat)
print('adj:',adj)


"""加入图池化UNets"""

end_time = time.time()
extime = end_time - start_time

print("加载A～的时间：", extime)
# Model and optimizer
model = GNN(nfeat=features.shape[1],
            nhid=args.hidden,
            nclass=labels.max().item() + 1,
            dropout=args.dropout,
            ks=args.ks)

optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)


def train(epoch):
    t = time.time()
    model.train()
    optimizer.zero_grad()
    output = model(features, adj)
    #for name, param in model.named_parameters():
     #   print(f"Parameter: {name}, Size: {param.size()}, data : {param.data}")
      #  print(param)
       # print("=" * 50)
    loss_train = F.nll_loss(output[idx_train], labels[idx_train])
    acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()

    #max_gradient = 1.0
    #torch.nn.utils.clip_grad_norm(model.parameters(), max_gradient)

    optimizer.step()

    if not args.fastmode:
        # Evaluate validation set performance separately, deactivates dropout during validation run.
        model.eval()
        output = model(features, adj)

    loss_val = F.nll_loss(output[idx_val], labels[idx_val])
    acc_val = accuracy(output[idx_val], labels[idx_val])
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.item()),
          'acc_train: {:.4f}'.format(acc_train.item()),
          'loss_val: {:.4f}'.format(loss_val.item()),
          'acc_val: {:.4f}'.format(acc_val.item()),
          'time: {:.4f}s'.format(time.time() - t))

def test():
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))
    line_str = 'epoch : %d ,drop : %f , lr : %f，Data--%s: test loss : %.5f, test acc : %.5f\n'
    with open('./result.txt', 'a+')as f:
        f.write(line_str % (args.epochs,args.dropout, args.lr,args.dataset,loss_test, acc_test))
# Train model
t_total = time.time()
for epoch in range(args.epochs):
    train(epoch)
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

# Testing
test()



